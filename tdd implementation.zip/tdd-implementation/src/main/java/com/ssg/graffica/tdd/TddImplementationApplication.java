package com.ssg.graffica.tdd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TddImplementationApplication {

	public static void main(String[] args) {
		SpringApplication.run(TddImplementationApplication.class, args);
	}

}
