# LastPrice API – Spring Boot

**Lightweight asynchronous price ingestion with in-memory batch queue**

### Features
- Max 5 prices per batch (configurable)
- Async producer → queue → consumer → DB
- Get latest price or price by ID
- Simulated delays for demo purposes

### Base URL
http://localhost:8080/price


### API Endpoints – Try in This Exact Order

| Method | Endpoint               | Purpose                                      | Request Body / Note                              |
|-------|------------------------|----------------------------------------------|--------------------------------------------------|
| POST  | `/price/queue`         | Add up to 5 prices to the queue              | JSON array (max 5 items)                         |
| POST  | `/price/add`           | Consume queue → save all prices to DB        | No body needed – wait ~5–10 sec                  |
| GET   | `/price/latest`        | Get the most recently saved price            | Returns `{ "Result": { ... } }`                  |
| GET   | `/price/{id}`          | Get price by its UUID                        | Use `id` from `/add` response                    |

### Step-by-Step Demo

1. **Queue prices**
   ```http
   POST http://localhost:8080/price/queue
   Content-Type: application/json

   [
     {
       "instrumentId": "BANK",
       "financeInstrument": {
         "instrumentSource": "bankAcc",
         "amount": 8500000.00,
         "sender": "SBI",
         "receiver": "Infosys"
       }
     },
     {
       "instrumentId": "NBFC",
       "financeInstrument": {
         "instrumentSource": "loan",
         "amount": 20000000.00,
         "sender": "Bajaj Finance",
         "receiver": "Tata Motors"
       }
     }
   ]

Response: true (201 Created)

2. Save queued prices to DB

POST http://localhost:8080/price/add

Wait a few seconds → returns saved prices with their generated ids

3. Get latest price
   GET http://localhost:8080/price/latest

4. Get price by ID (use an id from step 2)

   GET http://localhost:8080/price/a1b2c3d4-5678-90ef-ghij-klmnopqrstuv

Ready to use single price JSON:

```declarative
{
  "instrumentId": "SFB",
  "financeInstrument": {
    "instrumentSource": "wallet",
    "amount": 5000000.75,
    "sender": "Paytm",
    "receiver": "Flipkart"
  }
}
```

Tech Stack

Spring Boot 3
Spring Data JPA
H2 in-memory database (auto-configured)
CompletableFuture + BlockingQueue for async batch processing
