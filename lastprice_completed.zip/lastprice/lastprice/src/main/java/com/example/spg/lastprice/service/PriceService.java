package com.example.spg.lastprice.service;

import com.example.spg.lastprice.entity.Price;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;

public interface PriceService {
   
   CompletableFuture<Boolean> insertPrices(List<Price> prices);
   CompletableFuture<List<Price>> get();
   
   Optional<Price> processPricesById(String id);
   boolean insertPricesInQueueById(String id);
   Optional<Price> fetchLastUpdatePriceByAsOf();
   
}
