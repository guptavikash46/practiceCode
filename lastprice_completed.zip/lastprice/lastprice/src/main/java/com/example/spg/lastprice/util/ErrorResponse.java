package com.example.spg.lastprice.util;

import java.util.UUID;

public class ErrorResponse {
   
   private String id = UUID.randomUUID().toString();
   
   private String message;
   
   public ErrorResponse(String message) {
      this.message = message;
   }
   
   public String getId() {
      return id;
   }
   
   public String getMessage() {
      return message;
   }
}
