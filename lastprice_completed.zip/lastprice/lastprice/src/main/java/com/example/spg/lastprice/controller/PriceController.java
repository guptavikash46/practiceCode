package com.example.spg.lastprice.controller;

import com.example.spg.lastprice.entity.Price;
import com.example.spg.lastprice.service.PriceService;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/price")
public class PriceController {
   
   private static final String RESPONSE_KEY = "Result";
   private static final String ERROR_KEY = "Error";
   private final PriceService priceService;
   
   public PriceController(PriceService priceService) {
     this.priceService = priceService;
   }
   
   @PostMapping("/queue")
   public ResponseEntity<Boolean> addPrices(@RequestBody List<Price> prices) {
      //setting batch size to 5 items at a time only, this can be modified.
      if (prices.size() > 5) {
         return new ResponseEntity<>(false, HttpStatus.BAD_REQUEST);
      }
      return new ResponseEntity<>(priceService.insertPrices(prices).join(), HttpStatus.CREATED);
   }
   
   @PostMapping("/add")
   public ResponseEntity<List<Price>> addQueuedPricesInDb() {
      return new ResponseEntity<>(priceService.get().join(), HttpStatus.CREATED);
      
   }
   
   @GetMapping("/{id}")
   public ResponseEntity<Map<String, Price>> priceById(@PathVariable("id") String id) {
      boolean isInTheQueue = priceService.insertPricesInQueueById(id);
      if (isInTheQueue) {
         Optional<Price> price = priceService.processPricesById(id);
         if (price.isPresent()) {
            return new ResponseEntity<>(Map.of(RESPONSE_KEY, price.get()), HttpStatus.OK);
         }
      }
      return new ResponseEntity<>(Map.of(RESPONSE_KEY, new Price()), HttpStatus.BAD_REQUEST);
   }
   
   @GetMapping("/latest")
   public ResponseEntity<Map<String, Price>> lastPrice() {
      Optional<Price> latestPrice = priceService.fetchLastUpdatePriceByAsOf();
      if (latestPrice.isPresent()) {
         return new ResponseEntity<>(Map.of(RESPONSE_KEY, latestPrice.get()), HttpStatus.OK);
      }
      return new ResponseEntity<>(Map.of(RESPONSE_KEY, new Price()), HttpStatus.BAD_REQUEST);
      
   }
}
