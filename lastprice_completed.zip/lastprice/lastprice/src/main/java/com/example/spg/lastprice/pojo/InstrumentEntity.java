package com.example.spg.lastprice.pojo;

public enum InstrumentEntity {

   BANK("BANK"),
   NBFC("NBFC"),
   SFB("SFB"),
   PB("PB");
   
   private final String instrumentEntity;
   
   InstrumentEntity(String entity){
      this.instrumentEntity = entity;
   }
   
   public String getInstrumentEntity() {
      return instrumentEntity;
   }
}
