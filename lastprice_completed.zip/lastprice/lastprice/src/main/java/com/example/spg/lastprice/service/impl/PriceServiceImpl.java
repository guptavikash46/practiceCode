package com.example.spg.lastprice.service.impl;

import com.example.spg.lastprice.entity.Price;
import com.example.spg.lastprice.repository.PriceRepository;
import com.example.spg.lastprice.service.PriceService;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import org.springframework.stereotype.Service;

@Service
public class PriceServiceImpl implements PriceService {
   
   private final PriceRepository priceRepository;
   private static boolean isCompleted = false;
   private static final int BATCH_SIZE = 5;
   private BlockingQueue<Price> submitPrices = new LinkedBlockingQueue<>(BATCH_SIZE);
   private BlockingQueue<Price> failedSubmitPrices = new LinkedBlockingQueue<>();
   private BlockingQueue<String> pricesById = new LinkedBlockingQueue<>();
   private CompletableFuture<Boolean> producePrices;
   private CompletableFuture<List<Price>> fetchPrices;
   private List<Price> currentPrice;
   
   public PriceServiceImpl(PriceRepository priceRepository) {
      this.priceRepository = priceRepository;
      producePrices = new CompletableFuture<>();
      fetchPrices = new CompletableFuture<>();
      currentPrice = new ArrayList<>();
   }
   
   /**
    * Asynchronously inserts a list of Price objects into an internal blocking queue
    * for batched processing. Each price is added with a 1-second delay simulation.
    *
    * @param prices the list of Price objects to be queued
    * @return CompletableFuture<Boolean> indicating whether all prices were successfully queued
    */
   @Override
   public CompletableFuture<Boolean> insertPrices(List<Price> prices) {
      producePrices = CompletableFuture.supplyAsync(() -> {
         for (Price p : prices) {
            try {
               submitPrices.put(p);
               isCompleted = true;
               System.out.println("is inserted in queue? ->: " + isCompleted);
               Thread.sleep(1000);
            } catch (InterruptedException e) {
               isCompleted = false;
               failedSubmitPrices.add(p);
               System.out.println("Exception occured while pushing values in the queue....");
               System.out.println("Failed items queue size: " + failedSubmitPrices.size());
               throw new RuntimeException(e);
            }
         }
         System.out.println("Finished pushing in the queue.....");
         return isCompleted;
      });
      return producePrices;
   }
   
   /**
    * Consumes prices from the internal queue and persists them to the database.
    * Starts processing only after {@link #insertPrices(List)} completes.
    * Applies a 10-second timeout and returns an empty list on failure.
    *
    * @return CompletableFuture containing the list of successfully saved Price objects
    */
   @Override
   public CompletableFuture<List<Price>> get() {
      currentPrice.clear();
      fetchPrices = producePrices.thenApplyAsync(priceAvailableStatus -> {
         try {
            System.out.println("is producing Prices thread finished? ->" + producePrices.isDone());
            while (!submitPrices.isEmpty()) {
               Price price = submitPrices.take();
               currentPrice.add(price);
               priceRepository.save(price);
               System.out.println("Reading from the queue.... | current size of queue ->: " + submitPrices.size());
               Thread.sleep(1000);
            }
         } catch (InterruptedException e) {
            System.out.println("Exception occured while getting price from producer queue.");
            throw new RuntimeException(e);
         }
         return currentPrice;
      }).exceptionally(throwable -> {
         // This block runs only if the above stage throws
         System.out.println("Error in price processing pipeline: " + throwable.getMessage());
         return Collections.emptyList(); // graceful degradation);
         
      }).orTimeout(10, TimeUnit.SECONDS);
      System.out.println("is consuming Prices thread finished? ->" + fetchPrices.isDone());
      return fetchPrices;
   }
   
   /**
    * Adds a price ID to a dedicated queue for individual processing.
    * Used for selective or on-demand price retrieval by ID.
    *
    * @param id the ID of the price to be processed later
    * @return true if the ID was successfully queued, false if interrupted
    */
   @Override
   public boolean insertPricesInQueueById(String id) {
      try {
         pricesById.put(id);
         return true;
      } catch (InterruptedException e) {
         System.out.println("Error occured while inserting IDs of prices in queue.... ->" + e.getMessage());
      }
      return false;
   }
   
   /**
    * Processes the next price ID from the queue and retrieves the corresponding
    * Price entity from the repository. Only works if the batch insertion has completed.
    *
    * @param id not used directly — ID is taken from internal queue
    * @return Optional containing the Price if found, empty otherwise
    */
   @Override
   public Optional<Price> processPricesById(String id) {
      if (producePrices.isDone()) {
         try {
            String currentId = pricesById.take();
            return priceRepository.findById(currentId);
         } catch (InterruptedException e) {
            System.out.println("Error occured while reading IDs of prices from queue.... ->" + e.getMessage());
         }
      }
      return Optional.empty();
   }
   
   /**
    * Retrieves the most recently saved Price based on the 'asOf' timestamp.
    * Only returns a result if the batch price production has fully completed.
    *
    * @return Optional containing the latest Price by asOf timestamp, or empty if not ready
    */
   @Override
   public Optional<Price> fetchLastUpdatePriceByAsOf() {
      if (producePrices.isDone()) {
         return Optional.of(priceRepository.findFirstByOrderByAsOfDesc());
      }
      return Optional.empty();
   }
   
}
