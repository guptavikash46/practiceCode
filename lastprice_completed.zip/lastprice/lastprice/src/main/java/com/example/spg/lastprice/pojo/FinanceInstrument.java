package com.example.spg.lastprice.pojo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


public class FinanceInstrument {
   
   //This can be following: cash, loan, wallet, bankAcc, cheque, DD
   private String instrumentSource;
   private float amount;
   private String sender;
   private String receiver;
   
   public FinanceInstrument(String instrumentSource, float amount, String sender, String receiver) {
      this.instrumentSource = instrumentSource;
      this.amount = amount;
      this.sender = sender;
      this.receiver = receiver;
   }
   
   public FinanceInstrument() {}
   
   public String getInstrumentSource() {
      return instrumentSource;
   }
   
   public float getAmount() {
      return amount;
   }
   
   public String getSender() {
      return sender;
   }
   
   public String getReceiver() {
      return receiver;
   }
   
   @Override
   public String toString() {
      return "FinanceInstrument{" +
            "instrumentSource='" + instrumentSource + '\'' +
            ", amount=" + amount +
            ", sender='" + sender + '\'' +
            ", receiver='" + receiver + '\'' +
            '}';
   }
}
