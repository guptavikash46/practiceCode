package com.example.spg.lastprice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LastpriceApplication {

	public static void main(String[] args) {
		SpringApplication.run(LastpriceApplication.class, args);
	}

}
