package com.example.spg.lastprice.entity;

import com.example.spg.lastprice.pojo.FinanceInstrument;
import com.example.spg.lastprice.pojo.InstrumentEntity;
import jakarta.persistence.Embedded;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import java.time.LocalDateTime;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

@Entity
public class Price {
   
   @Id
   private String id = UUID.randomUUID().toString();
   
   //This can be a financial entity.
   private InstrumentEntity instrumentId;
   
   private LocalDateTime asOf = LocalDateTime.now().minusSeconds(ThreadLocalRandom.current().nextInt(1, 59));
   
   @Embedded
   private FinanceInstrument financeInstrument;
   
   public Price() {}
   
   public Price(FinanceInstrument financeInstrument, InstrumentEntity instrumentId) {
      this.financeInstrument = financeInstrument;
      this.instrumentId = instrumentId;
   }
   
   public String getId() {
      return id;
   }
   
   public InstrumentEntity getInstrumentId() {
      return instrumentId;
   }
   
   public LocalDateTime getAsOf() {
      return asOf;
   }
   
   public FinanceInstrument getFinanceInstrument() {
      return financeInstrument;
   }
   @Override
   public String toString() {
      return "Price{" +
            "id='" + id + '\'' +
            ", instrumentId=" + instrumentId +
            ", asOf=" + asOf +
            ", financeInstrument=" + financeInstrument +
            '}';
   }
}
